#include "stdafx.h"
#include "Search.h"
#include "Declare_Vari.h"
void Search(Ego ego, int &Task,std::vector<int> &velID)
{
	double x1,x2,y1,y2;
	double x_neig1,x_neig2,y_neig1,y_neig2;
	double dis = 1000000000,dis_neig=1000000000;
	bool flag = 1,flag_neig=1;
	if(!(ego.X>=-18&&ego.X<=18&&ego.Y>=-18&&ego.Y<=18))//����Գ�����ʮ��·��
	{
		if(ego.X<-18&&ego.Y<-3.75)//�ڽ���ʮ��·��ǰ��ֱ������೵��
		{
			x1=ego.X,x2=0,y1=-7.5,y2=-3.75;//����x2=0������-18����Ϊ��ֹ����ס��Ŀ���ȴ��ⲻ���������36�����⳵�����Ŀ���Լ���Գ��Ŀ��ȵ��ж�����ͬ��
			x_neig1=ego.X;x_neig2=0;y_neig1=-3.75;y_neig2=0;//��ǰ����������ſ����ܻᵼ�¼�⵽��ǰ�������ǵ�ס�켣�滮���Ǹ�ǰ����ֻ����Ϊ����⵽�ˣ���������ǰ��ĳ���ס�˹켣�滮�������������ܷ��������⳵�����ʱ����������ƫ��ȫ��
		}
		else if(ego.X<-18&&ego.Y>=-3.75)//�ڽ���ʮ��·��ǰ��ֱ�����ڲ೵��
		{
			x1=ego.X,x2=0,y1=-3.75,y2=0;
			x_neig1=ego.X,x_neig2=0,y_neig1=-7.5,y_neig2=-3.75;
		}
		for (int i = 0; i < velID.size(); i++)
		{
			int id = velID[i];
			if (vel[id].flag)
			{

				double prex = vel[id].X, prey = vel[id].Y;
				if (prex > x1 && prex < x2 && prey > y1 && prey < y2)
				{
					flag = 0;
					double now_dis = (prex - ego.X)*(prex - ego.X) + (prey - ego.Y)*(prey - ego.Y);
					if (now_dis < dis)
					{
						dis = now_dis;
						frontvel[0]=id;
					}
				}
				if (prex > x_neig1 && prex < x_neig2 && prey > y_neig1 && prey < y_neig2)
				{
					flag_neig = 0;
					double now_dis = (prex - ego.X)*(prex - ego.X) + (prey - ego.Y)*(prey - ego.Y);
					if (now_dis < dis_neig)
					{
						dis_neig = now_dis;
						frontvel[1]=id;
					}
				}
			}
		}
		if(flag==1)
			frontvel[0]=-1;
		if(flag_neig==1)
			frontvel[1]=-1;
	}
	else if(Task==1)//ʮ��·��ֱ��
	{
		if(ego.Y<-3.75)
		{
			x1=ego.X,x2=36,y1=-7.5,y2=-3.75;
			x_neig1=ego.X;x_neig2=36;y_neig1=-3.75;y_neig2=0;
		}
		else if(ego.Y>=-3.75)
		{
			x1=ego.X,x2=36,y1=-3.75,y2=0;
			x_neig1=ego.X,x_neig2=36,y_neig1=-7.5,y_neig2=-3.75;
		}
		for (int i = 0; i < velID.size(); i++)
		{
			int id = velID[i];
			if (vel[id].flag)
			{

				double prex = vel[id].X, prey = vel[id].Y;
				if (prex > x1 && prex < x2 && prey > y1 && prey < y2)
				{
					flag = 0;
					double now_dis = (prex - ego.X)*(prex - ego.X) + (prey - ego.Y)*(prey - ego.Y);
					if (now_dis < dis)
					{
						dis = now_dis;
						frontvel[0]=id;
					}
				}
				if (prex > x_neig1 && prex < x_neig2 && prey > y_neig1 && prey < y_neig2)
				{
					flag_neig = 0;
					double now_dis = (prex - ego.X)*(prex - ego.X) + (prey - ego.Y)*(prey - ego.Y);
					if (now_dis < dis_neig)
					{
						dis_neig = now_dis;
						frontvel[1]=id;
					}
				}
			}
		}
		if(flag==1)
			frontvel[0]=-1;
		if(flag_neig==1)
			frontvel[1]=-1;
	}
	else if(Task==2)//ʮ��·����ת
	{
		for (int i = 0; i < velID.size(); i++)
		{
			int id = velID[i];
			if (vel[id].flag)
			{
				double prex = vel[id].X, prey = vel[id].Y;
				if(ego.X<-TurnLeftR)
				{
					if((prex>ego.X&&prex<-TurnLeftR&&prey<0&&prey>-3.75)||(prex>-TurnLeftR&&prey<TurnLeftR&&((prex+TurnLeftR)*(prex+TurnLeftR)+(prey-TurnLeftR)*(prey-TurnLeftR))>=pow(TurnLeftR+3.75/2-2,2)&&((prex+TurnLeftR)*(prex+TurnLeftR)+(prey-TurnLeftR)*(prey-TurnLeftR))<=pow(TurnLeftR+3.75/2+2,2))||
						(prex > 0 && prex < 3.75 && prey > TurnLeftR && prey < 18+20))
					{
						flag = 0;
						double now_dis = (prex - ego.X)*(prex - ego.X) + (prey - ego.Y)*(prey - ego.Y);
						if (now_dis < dis)
						{
							dis = now_dis;
							frontvel[0]=id;
						}
					}
				}
				else if(ego.Y>TurnLeftR)
				{
					if(prex > 0 && prex < 3.75 && prey > ego.Y && prey < 18+20)
					{
						flag = 0;
						double now_dis = (prex - ego.X)*(prex - ego.X) + (prey - ego.Y)*(prey - ego.Y);
						if (now_dis < dis)
						{
							dis = now_dis;
							frontvel[0]=id;
						}
					}

				}
				else
				{
					if((prex>ego.X&&prey>ego.Y&&prey<TurnLeftR&&((prex+TurnLeftR)*(prex+TurnLeftR)+(prey-TurnLeftR)*(prey-TurnLeftR))>=pow(TurnLeftR+3.75/2-2,2)&&((prex+TurnLeftR)*(prex+TurnLeftR)+(prey-TurnLeftR)*(prey-TurnLeftR))<=pow(TurnLeftR+3.75/2+2,2))||
						(prex > 0 && prex < 3.75 && prey > TurnLeftR && prey < 18+20))
					{
						flag = 0;
						double now_dis = (prex - ego.X)*(prex - ego.X) + (prey - ego.Y)*(prey - ego.Y);
						if (now_dis < dis)
						{
							dis = now_dis;
							frontvel[0]=id;
						}
					}
				}
			}
		}
		frontvel[1]=-1;
		if(flag==1)
			frontvel[0]=-1;
	}
	else if(Task==3)//ʮ��·����ת
	{
		for (int i = 0; i < velID.size(); i++)
		{
			int id = velID[i];
			if (vel[id].flag)
			{

				double prex = vel[id].X, prey = vel[id].Y;
				if((prex>ego.X&&prey>=-18&&((prex+18)*(prex+18)+(prey+18)*(prey+18))>=pow(18-3*3.75/2-2,2)&&((prex+18)*(prex+18)+(prey+18)*(prey+18))<=pow(18-3*3.75/2+2,2))||
					(prex > -7.5 && prex < -3.75 && prey > -36 && prey < -18))
				{
					flag = 0;
					double now_dis = (prex - ego.X)*(prex - ego.X) + (prey - ego.Y)*(prey - ego.Y);
					if (now_dis < dis)
					{
						dis = now_dis;
						frontvel[0]=id;
					}
				}
			}
		}
		frontvel[1]=-1;
		if(flag==1)
			frontvel[0]=-1;
	}
	if(frontvel[0]==-1&&frontvel[1]!=-1)
	{
		if(fabs(vel[frontvel[1]].Y-map.line[ego.LocalLane].boundLine)<1&&!ego.is_intersection)
			frontvel[0]=frontvel[1];
	}
	else if(frontvel[0]!=-1&&frontvel[1]==-1)
	{
		if(fabs(vel[frontvel[0]].Y-map.line[ego.LocalLane].boundLine)<1&&!ego.is_intersection)
			frontvel[1]=frontvel[0];
	}
	else if(frontvel[0]!=-1&&frontvel[1]!=-1)
	{
		if(fabs(vel[frontvel[1]].Y-map.line[ego.LocalLane].boundLine)<1
			&&!ego.is_intersection&&vel[frontvel[1]].X<vel[frontvel[0]].X)
			frontvel[0]=frontvel[1];
		else if(fabs(vel[frontvel[0]].Y-map.line[ego.LocalLane].boundLine)<1
			&&!ego.is_intersection&&vel[frontvel[0]].X<vel[frontvel[1]].X)
			frontvel[1]=frontvel[0];
	}
}