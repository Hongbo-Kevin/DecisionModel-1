#pragma once
#include <vector>
using namespace std;
typedef struct ExpNodes_T {
	int x, y, v;
	double r;
	double Gn, Hn, Fn;
	void set(int _x, int _y, double _r, int _v, double _Gn, double _Hn, double _Fn)
	{
		x = _x;
		y = _y;
		r = _r;
		v = _v;
		Gn = _Gn;
		Hn = _Hn;
		Fn = _Fn;
	}
}ExpNodes_t;
#ifndef __EXPAND_NODES_DYNAMIC_H__
#define __EXPAND_NODES_DYNAMIC_H__
std::vector<ExpNodes_t>Expand_Nodes_Dynamic(int node_x, int node_y, double node_r, int node_v, int node_t,
	double gn, int TargeX, int TargetY, int TargetDesireV,double centerline,int Max_X, int Max_Y, int Max_V,
	char *Map3D[], std::vector<double*> &ClosedSet, double TTS,char *Map3D_0[],double *w,bool overtaking_flag);
#endif


