#pragma once
using namespace std;
#ifndef __APF_H__
#define __APF_H__
double APF(int node_t, int x, int y, int v);
#endif