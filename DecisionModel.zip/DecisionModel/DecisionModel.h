#ifdef DECISIONMODEL_EXPORTS
#define DECISIONMODEL_API __declspec(dllexport)
#else
#define DECISIONMODEL_API __declspec(dllimport)
#endif
struct output_path;
extern "C" DECISIONMODEL_API int init();
extern "C" DECISIONMODEL_API int set_ego(float x,float y,float v,float heading);
extern "C" DECISIONMODEL_API int clear_vel_list();
extern "C" DECISIONMODEL_API int set_vel(int id,float x,float y,float v,float length,float width,float yaw);
extern "C" DECISIONMODEL_API int set_task(int task);
extern "C" DECISIONMODEL_API int set_trafficLight(int trafficlight);
extern "C" DECISIONMODEL_API int trajectory_plan();
extern "C" DECISIONMODEL_API int get_total_num(int *total_num);
extern "C" DECISIONMODEL_API int get_optimal_path(output_path *path);
extern "C" DECISIONMODEL_API int delete_p();