#pragma once
#ifndef __CAL_DIST_H__
#define __CAL_DIST_H__
double Cal_Dist(int x1, int y1, int x2, int y2);
#endif