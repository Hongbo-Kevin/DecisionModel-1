#include "stdafx.h"
#include "MAP.h"
//��ʼ����ͼ�Ϳ�������
Map::Map()
{
	OFFSET_X=3110;
	OFFSET_Y=190;
	GridLength=3301;
	GridWidth=381;
}
void Map::initMap()
{
	line[B0000].centerLine = -3.75 / 2.0, line[B0000].flag1 = 1, line[B0000].stopLine = -18.0, line[B0000].flag2 = 0;
	line[B0000].boundLine = -3.75;

	line[B0001].centerLine = -3.75 / 2.0 - 3.75, line[B0001].flag1 = 1, line[B0001].stopLine = -18.0, line[B0001].flag2 = 0;
	line[B0001].boundLine = -3.75;

	line[B0110].centerLine = 3.75 / 2.0, line[B0110].flag1 = 1, line[B0110].stopLine = -18.0, line[B0110].flag2 = 0;
	line[B0110].boundLine = 3.75;

	line[B0111].centerLine = 3.75 / 2.0 + 3.75, line[B0111].flag1 = 1, line[B0111].stopLine = -18.0, line[B0111].flag2 = 0;
	line[B0111].boundLine = 3.75;

	line[B0010].centerLine = -3.75 / 2.0, line[B0010].flag1 = 1, line[B0010].stopLine = 18.0, line[B0010].flag2 = 0;
	line[B0010].boundLine = -3.75;

	line[B0011].centerLine = -3.75 / 2.0 - 3.75, line[B0011].flag1 = 1, line[B0011].stopLine = 18.0, line[B0011].flag2 = 0;
	line[B0011].boundLine = -3.75;

	line[B0100].centerLine = 3.75 / 2.0, line[B0100].flag1 = 1, line[B0100].stopLine = 18.0, line[B0100].flag2 = 0;
	line[B0100].boundLine = 3.75;

	line[B0101].centerLine = 3.75 / 2.0 + 3.75, line[B0101].flag1 = 1, line[B0101].stopLine = 18.0, line[B0101].flag2 = 0;
	line[B0101].boundLine = 3.75;

	line[B1110].centerLine = -3.75 / 2.0, line[B1110].flag1 = 0, line[B1110].stopLine = -18.0, line[B1110].flag2 = 1;
	line[B1110].boundLine = -3.75;

	line[B1111].centerLine = -3.75 / 2.0 - 3.75, line[B1111].flag1 = 0, line[B1111].stopLine = -18.0, line[B1111].flag2 = 1;
	line[B1111].boundLine = -3.75;

	line[B1000].centerLine = 3.75 / 2.0, line[B1000].flag1 = 0, line[B1000].stopLine = -18.0, line[B1000].flag2 = 1;
	line[B1000].boundLine = 3.75;

	line[B1001].centerLine = 3.75 / 2.0 + 3.75, line[B1001].flag1 = 0, line[B1001].stopLine = -18.0, line[B1001].flag2 = 1;
	line[B1001].boundLine = 3.75;

	line[B1100].centerLine = -3.75 / 2.0, line[B1100].flag1 = 0, line[B1100].stopLine = 18.0, line[B1100].flag2 = 1;
	line[B1100].boundLine = -3.75;

	line[B1101].centerLine = -3.75 / 2.0 - 3.75, line[B1101].flag1 = 0, line[B1101].stopLine = 18.0, line[B1101].flag2 = 1;
	line[B1101].boundLine = -3.75;

	line[B1010].centerLine = 3.75 / 2.0, line[B1010].flag1 = 0, line[B1010].stopLine = 18.0, line[B1010].flag2 = 1;
	line[B1010].boundLine = 3.75;

	line[B1011].centerLine = 3.75 / 2.0 + 3.75, line[B1011].flag1 = 0, line[B1011].stopLine = 18.0, line[B1011].flag2 = 1;
	line[B1011].boundLine = 3.75;


	char *temp_ptr = new char[GridLength*GridWidth];
	Passable_pre.surface = new char*[GridLength];
	for (int i = 0; i < GridLength; i++)
		Passable_pre.surface[i] = temp_ptr + i*GridWidth;
	for(int i=0;i<GridLength;i++)
	{
		for(int j=0;j<GridWidth;j++)
		{
			Geo a=grid2geo(i,j);
			double x=a.geox;
			double y=a.geoy;
			if(y>-7.5+1.2&&y<-1.2)
				Passable_pre.surface[i][j]=49;
			else if(y>18&&x>1.2&&x<3.75-1.2)//�ϱ�ֱ��
				Passable_pre.surface[i][j]=49;
			else if(x>=-18&&y<=18&&((x+18)*(x+18)+(y-18)*(y-18))
				>=pow(18+3.75/2-0.5,2)&&((x+18)*(x+18)+(y-18)*(y-18))<=pow(18+3.75/2+0.5,2))//��ת���⳵��
				Passable_pre.surface[i][j]=49;
			else if(y<-18&&x>-7.5+1.2&&x<-3.75-1.2)//�ϱ�ֱ��
				Passable_pre.surface[i][j]=49;
			else if(x>=-18&&y>=-18&&((x+18)*(x+18)+(y+18)*(y+18))
				>=pow(18-3*3.75/2-0.5,2)&&((x+18)*(x+18)+(y+18)*(y+18))<=pow(18-3*3.75/2+0.5,2))//��ת���⳵��
				Passable_pre.surface[i][j]=49;
			else
				Passable_pre.surface[i][j]=48;
		}
	}
}

//�������ڳ���
int Map::get_LocalLane(double x, double y)
{
	//��λ���� 1111 ��ʾ �ϱ��������򳵵����ɱ����ϣ���Զ��·�ڣ���೵��
	int locallane = -1;
	if (x < -18)
	{
		if (y > -7.5 && y < -3.75)   locallane = B0001;
		else if (y < 0)              locallane = B0000;
		else if (y < 3.75)           locallane = B0110;
		else if (y < 7.5)            locallane = B0111;
	}
	else if (x > 18)
	{
		if (y > -7.5 && y < -3.75)   locallane = B0011;
		else if (y < 0)              locallane = B0010;
		else if (y < 3.75)           locallane = B0100;
		else if (y < 7.5)            locallane = B0101;
	}

	if (y < -18)
	{
		if (x > -7.5 && x < -3.75)   locallane = B1111;
		else if (x < 0)              locallane = B1110;
		else if (x < 3.75)           locallane = B1000;
		else if (x < 7.5)            locallane = B1001;
	}
	else if (y > 18)
	{
		if (x > -7.5 && x < -3.75)   locallane = B1101;
		else if (x < 0)              locallane = B1100;
		else if (x < 3.75)           locallane = B1010;
		else if (x < 7.5)            locallane = B1011;
	}
	return locallane;
}

//��ͼ����ת��Ϊ��������
Grid Map::geo2grid(double x,double y)
{
	int X,Y;
	if(x>=0)
		X=int(x*5+0.5);
	else
		X=int(x*5-0.5);
	if(y>=0)
		Y=int(y*5+0.5);
	else
		Y=int(y*5-0.5);
	Grid grid;
	grid.gridx=X+this->OFFSET_X;
	grid.gridy=Y+this->OFFSET_Y;
	return grid;
}


//��������ת��Ϊ��ͼ����
Geo Map::grid2geo(int x,int y)
{
	Geo geo;
	geo.geox=(x-this->OFFSET_X)/5.0;
	geo.geoy=(y-this->OFFSET_Y)/5.0;
	return geo;
}

Map::~Map()
{
	delete[] Passable_pre.surface[0];
	delete[] Passable_pre.surface;
}
