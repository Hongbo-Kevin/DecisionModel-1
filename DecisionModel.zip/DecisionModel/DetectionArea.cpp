#include "stdafx.h"
#include "DetectionArea.h"
#include "Declare_Vari.h"
bool SurroundingVehicleDetection(Vel &m_vel, string area)
{
	//return false;
	double x1, x2, y1, y2;
	for (int i = 0; i < area.size(); i++)
	{
		char ch = area[i];
		if (ch == 'Z')
			x1 = ego.X, x2 = ego.X + 50, y1 = -7.5, y2 = 0;
		else if (ch == 'Y')
		{
			x1 = (ego.X>-584?ego.X-20:ego.X), x2 = ego.X;
			if(ego.Y>-3.75)
				y1 =-7.5, y2 = -3.75;
			else
				y1 = -3.75, y2 = 0;
		}
		else if (ch == 'A')
			x1 = ego.X, x2 = map.line[ego.LocalLane].stopLine, y1 = -7.5, y2 = 0;
		else if (ch == 'B')
			x1 = -7.5, x2 = 0, y1 = -18 - 50, y2 = -18;
		else if (ch == 'C')
			x1 = 0, x2 = 7.5, y1 = -18 - 50, y2 = -18;
		else if (ch == 'D')
			x1 = 18, x2 = 18 + 50, y1 = -7.5, y2 = 0;
		else if (ch == 'E')
			x1 = 18, x2 = 18 + 50, y1 = 0, y2 = 7.5;
		else if (ch == 'F')
			x1 = 0, x2 = 7.5, y1 = 18, y2 = 18 + 50;
		else if (ch == 'G')
			x1 = -7.5, x2 = 0, y1 = 18, y2 = 18 + 50;
		else if (ch == 'I')
			x1 = -18, x2 = 18, y1 = -18, y2 = 18;
		if (m_vel.X >=x1  && m_vel.X <= x2 && m_vel.Y >= y1 && m_vel.Y <= y2)//(x1>ego.X?x1:ego.X)
			return true;
	}
	return false;
}
//��ֵvel[].flag
void markInArea(string area, vector<int> &velID)
{
	for (int i = 0; i < velID.size(); i++)
	{
		int id = velID[i];
		vel[id].flag = SurroundingVehicleDetection(vel[id], area);
	}
}
//�õ��ܳ�ʶ������+��ֵvel[].flag
void DetectionArea(vector<int> &velID)
{
	string area;
	double dis = fabs(ego.X);
	if (dis > 18 + 50)
	{
		area += "Z";    //�Գ�ǰ��50m˫������Χ��{Ego.LocalX<x<Ego.LocalX+50, -7.5<y<0}
		area += "Y";    //�Գ���20m˫������Χ��{Ego.LocalX-20<x<Ego.LocalX, -7.5<y<0}
	}
	else if (dis >= 18)
	{
		area = "A";
		if (Task == 2)
			area += "EFI";
		else if (Task == 3)
			area += "BEGI";
		else if (Task == 1)
			area += "CDGIY";
	}
	else    //��ʮ��·������ʱ
	{
		if (Task == 2)
			area = "EFIG";
		else if (Task == 3)
		{
			area = "BEI";
			if(ego.X<-1.875)
				area+='G';
		}
		else if (Task == 1)
			area = "CDGIY";
	}
	markInArea(area, velID);
	return;
}