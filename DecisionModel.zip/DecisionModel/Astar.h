#pragma once
#include "EGO.h"
#ifndef __ASTAR_H__
#define __ASTAR_H__
bool Astar_algorithm(Ego ego, Target &target, std::vector<int> &velID,int sequence_flag);
#endif