#include "stdafx.h"
#include "VEL.h"
#include "Cal_Dist.h"
#include "Declare_Vari.h"


int Vel::size_location=decision_freq;//��ֵVel���еľ�̬��Ա
Vel::Vel()
{
	B=1;
	P[0]=1.0,P[1]=0,P[2]=0;
	T[0][0]=0.6,T[0][1]=0.2,T[0][2]=0.2,
		T[1][0]=0.2,T[1][1]=0.6,T[1][2]=0.2,
		T[2][0]=0.2,T[2][1]=0.2,T[2][2]=0.6;
	
}

void Vel::TrajectoryPrediction()//ofstream &outfile
{
	if(this->location.size()==0||(fabs(this->X-this->location[this->location.size()-1].X)<1&&
		fabs(this->Y-this->location[this->location.size()-1].Y)<1))//û����ʷ�켣������һ��������Ԥ�����г�������
	{
		for (int t = 0; t < TimeStep; t++)     //�Ե�ǰ�����ٶ�����Ԥ��5�룬�����ݹ켣���̲���������Ӧ����λ��
		{
			(*this).predicted[t].X = (*this).X;
			(*this).predicted[t].Y = (*this).Y;
			if(this->is_intersection)
				(*this).predicted[t].sita=SITA;
			else
			{
				if ((*this).LocalLane / 8 == 0)

					(*this).predicted[t].sita = (((*this).LocalLane >> 2) & 1)*PAI;
				else

					(*this).predicted[t].sita = PAI / 2.0 * (1 - 2 * (((*this).LocalLane >> 2) & 1));
			}
		}
		return;
	}
	double P2[3];

	double f1, f2, v;//f1Ϊ�복�������ߵľ��룬f2Ϊ0.1s����λ�ƾ���ֵ��vΪ0.1s����λ��
	if (!((*this).X>-18 && (*this).X < 18 && (*this).Y > -18 && (*this).Y < 18))    //�ܳ�����ʮ��·�����򣨼���ֱ����
	{
		if (((*this).LocalLane >> 3) == 0) //�ܳ���������ʻ
		{
			f1 = 3.75/2-fabs((*this).Y - map.line[(*this).LocalLane].boundLine);//
			f2 = fabs((*this).location[(*this).location.size() - 1].Y - (*this).Y);
			v = (*this).X - (*this).location[(*this).location.size() - 1].X;
		}
		else
		{
			f1 = 3.75/2-fabs((*this).X - map.line[(*this).LocalLane].boundLine);
			f2 = fabs((*this).location[(*this).location.size() - 1].X - (*this).X);
			v = (*this).Y - (*this).location[(*this).location.size() - 1].Y;
		}

		if (this->B !=2&&this->B!=3 )
		{
			if (((*this).LocalLane & 1) == 0)
				this->b = 3;//������ڲ೵�� �һ���
			else
				this->b = 2;//�������೵�� �󻻵�
		}
		double PyB[3] = { 0,0,0 };
		PyB[0] = exp(-f1*f1 - f2*f2);
		PyB[this->b-1] = 1.0 - PyB[0];
		for (int i = 0; i < 3; i++)
		{
			P2[i] = 0;
			for (int j = 0; j < 3; j++)
				P2[i] += (this->P[j] * this->T[j][i]);
		}
		for (int i = 0; i < 3; i++)
			this->P[i] = P2[i] * PyB[i];
		(*this).normaliz(this->P);
		this->B = (*this).argmax(this->P);
		if (this->B == 2 || this->B == 3)
		{
			double Xfit, Yfit, Xfit_his[10],Yfit_his[10],xcenter, ycenter;
			if ((*this).LocalLane / 8 == 0)
			{
				Xfit = (*this).X, Yfit = (*this).Y;
				for(int i=0;i<this->location.size();i++)
					Xfit_his[i]=this->location[i].X,Yfit_his[i]=this->location[i].Y;
			}
			else
			{
				Xfit = (*this).Y, Yfit = (*this).X;
				for(int i=0;i<this->location.size();i++)
					Xfit_his[i]=this->location[i].Y,Yfit_his[i]=this->location[i].X;
			}
			if ((*this).location[0].LocalLine != (*this).LocalLane)//�����ǰ�����ڳ����������¼�ĵ����ڳ�����ͬ����ôѡȡ�೵���ֽ�������ĵ���Ϊ���ĵ�
			{
				if((*this).location[this->location.size()-1].LocalLine != (*this).LocalLane)//�����ǰ��ǰһ����Ҳ�͵�ǰ�㲻��ͬһ��������˵����ǰ���Ǹ�Խ������ �Ǿ�����һ����Ϊ����
				{
					xcenter=Xfit_his[this->location.size()-1];
					ycenter=Yfit_his[this->location.size()-1];
				}
				else//�������ʷ�켣��ѡ��һ���복���ֽ�������ĵ�
				{
					int min_index=0;
					double min_dis=fabs(Yfit_his[0] - map.line[(*this).LocalLane].boundLine);
					for(int i=1;i<=this->location.size()-1;i++)
					{
						double current_dis=fabs(Yfit_his[i] - map.line[(*this).LocalLane].boundLine);
						if(current_dis<min_dis)
							min_index=i,min_dis=current_dis;
					}
					xcenter=Xfit_his[min_index];
					ycenter=Yfit_his[min_index];

				}
			}
			else
			{
				ycenter = map.line[(*this).LocalLane].boundLine;  //�������ֽ��ߺ�������
				f2=(f2>0.2?f2:0.2);
				xcenter = fabs((Yfit - ycenter) / f2) * v + Xfit;
			}

			double xfit,yfit;
			xfit = Xfit - xcenter,yfit = (Yfit - ycenter) / (3.75 / 2.0);
			double k;

			if ((yfit + 1)<0.1||(int)(2.0 / (yfit + 1)*100000)/100000.0 <=1) 
				k = 0.245;
			else
				k = log(2.0 / (yfit + 1) - 1) / xfit;

			for (int t = 0; t < TimeStep; t++)     //�Ե�ǰ�����ٶ�����Ԥ��5�룬�����ݹ켣���̲���������Ӧ����λ��
			{
				double Xfut = Xfit + v * (t+1);
				double xfut = Xfut - xcenter;
				double yfut = 2.0 / (1 + exp(k*xfut)) - 1.0;
				double Yfut = yfut / 2.0*3.75 +ycenter;
				if ((*this).LocalLane / 8 == 0)
				{
					(*this).predicted[t].X = Xfut;
					(*this).predicted[t].Y = Yfut;
					(*this).predicted[t].sita = (((*this).LocalLane >> 2) & 1) * PAI;
				}
				else
				{
					(*this).predicted[t].X = Yfut;
					(*this).predicted[t].Y = Xfut;
					(*this).predicted[t].sita = PAI / 2.0 * (1 - 2 * (((*this).LocalLane >> 2) & 1));
				}
			}
		}
		else if (this->B == 1) //���������ж��м�û�л���Ҳû��ת��
		{
			for (int t = 0; t < TimeStep; t++)
			{
				if ((*this).LocalLane / 8 == 0)
				{
					(*this).predicted[t].X = (*this).X + v * (t+1);
					(*this).predicted[t].Y = (*this).Y;
					(*this).predicted[t].sita = (((*this).LocalLane >> 2) & 1)*PAI;
				}
				else
				{
					(*this).predicted[t].X = (*this).X;
					(*this).predicted[t].Y = (*this).Y + v*(t+1);
					(*this).predicted[t].sita = PAI / 2.0 * (1 - 2 * (((*this).LocalLane >> 2) & 1));
				}
			}
		}
	}
	else //����ʮ��·��
	{
		//ʶ��

		int D,E;
		double R,sita0;

		if (((*this).LocalLane >> 3) == 0) //�ܳ���������ʻ
			v = (*this).X - (*this).location[(*this).location.size() - 1].X;
		else
			v = (*this).Y - (*this).location[(*this).location.size() - 1].Y;
		if(((*this).LocalLane==B0000)&&((*this).Y>-1))
		{
			this->B=4;
			D=-18;E=18;
			R=sqrt(pow((*this).X-D,2)+pow((*this).Y-E,2));
			sita0=asin(((*this).Y - E) / R);
		}
		else if(((*this).LocalLane==B0001)&&((*this).Y<-7.5+1))
		{
			this->B=5;
			D=-18;E=-18;
			R=sqrt(pow((*this).X-D,2)+pow((*this).Y-E,2));
			sita0=acos(((*this).X - D) / R);
		}
		else if(((*this).LocalLane==B1000)&&((*this).X<1))
		{
			this->B=4;
			D=-18;E=-18;
			R=sqrt(pow((*this).X-D,2)+pow((*this).Y-E,2));
			sita0=acos(((*this).X - D) / R);
		}
		else if(((*this).LocalLane==B1001)&&((*this).X>7.5-1))
		{
			this->B=5;
			D=18;E=-18;
			R=sqrt(pow((*this).X-D,2)+pow((*this).Y-E,2));
			sita0=acos(((*this).X - D) / R);
		}
		else if(((*this).LocalLane==B0100)&&((*this).Y<1))
		{
			this->B=4;
			D=18;E=-18;
			R=sqrt(pow((*this).X-D,2)+pow((*this).Y-E,2));
			sita0=acos(((*this).X - D) / R);
		}
		else if(((*this).LocalLane==B0101)&&((*this).Y>7.5-1))
		{
			this->B=5;
			D=18;E=18;
			R=sqrt(pow((*this).X-D,2)+pow((*this).Y-E,2));
			sita0=asin(fabs(((*this).Y - E))/ R)-PAI;//
		}
		else if(((*this).LocalLane==B1100)&&((*this).X>-1))
		{
			this->B=4;
			D=18;E=18;
			R=sqrt(pow((*this).X-D,2)+pow((*this).Y-E,2));
			sita0=asin(fabs(((*this).Y - E))/ R)-PAI;//
		}
		else if(((*this).LocalLane==B1101)&&((*this).X<-7.5+1))
		{
			this->B=5;
			D=-18;E=18;
			R=sqrt(pow((*this).X-D,2)+pow((*this).Y-E,2));
			sita0=asin(((*this).Y - E)/ R);
		}
		else
			this->B=1;
		//Ԥ��
		if(this->B!=1)
		{
			double w=(*this).V/R;
			for (int t = 0; t < TimeStep; t++)
			{
				double SiTa= sita0 + (this->B == 5 ? -1 : 1) * w *(t+1)*Ts;//������SiTa�����岻�ǳ�������Ƕ��ǳ������ĵ����ת��������ת�ĽǶ�
				if((*this).LocalLane==B0000)
					(*this).predicted[t].sita=PAI/2+SiTa;
				else if((*this).LocalLane==B0001)
					(*this).predicted[t].sita=-PAI/2+SiTa;
				else if((*this).LocalLane==B1000)
					(*this).predicted[t].sita=PAI/2+SiTa;
				else if((*this).LocalLane==B1001)
					(*this).predicted[t].sita=-PAI/2+SiTa;
				else if((*this).LocalLane==B0100)
					(*this).predicted[t].sita=-3*PAI/2+SiTa;
				else if((*this).LocalLane==B0101)
					(*this).predicted[t].sita=3*PAI/2+SiTa;
				else if((*this).LocalLane==B1100)
					(*this).predicted[t].sita=PAI/2+SiTa;
				else if((*this).LocalLane==B1101)
					(*this).predicted[t].sita=-PAI/2+SiTa;
				(*this).predicted[t].X = R*cos(SiTa) + D;
				(*this).predicted[t].Y = R*sin(SiTa) + E;
				if (!((*this).predicted[t].X > -18 && (*this).predicted[t].X < 18 && (*this).predicted[t].Y > -18 && (*this).predicted[t].Y < 18))//�������ʮ��·��
				{
					int go_out_time=t;
					while (t < TimeStep)
					{
						if ((*this).LocalLane == B0000)//������LocalLane��ʮ��·��ҲҪ����
						{
							(*this).predicted[t].X = 3.75 / 2.0;
							(*this).predicted[t].Y = 18 + (*this).V*(t-go_out_time+1)*Ts;
							(*this).predicted[t].sita = PAI / 2;
						}
						else if ((*this).LocalLane == B0001)
						{
							(*this).predicted[t].X = -3.75 - 3.75 / 2.0;
							(*this).predicted[t].Y = -18 - (*this).V*(t-go_out_time+1)*Ts;
							(*this).predicted[t].sita = -PAI / 2;
						}
						else if ((*this).LocalLane == B1000)
						{
							(*this).predicted[t].X = -18 - (*this).V*(t-go_out_time+1)*Ts;
							(*this).predicted[t].Y = 3.75 / 2.0;
							(*this).predicted[t].sita = PAI;
						}
						else if ((*this).LocalLane == B1001)
						{
							(*this).predicted[t].X = 18 + (*this).V*(t-go_out_time+1)*Ts;
							(*this).predicted[t].Y = -3.75 - 3.75 / 2.0;
							(*this).predicted[t].sita = 0;
						}
						else if ((*this).LocalLane == B0100)
						{
							(*this).predicted[t].X = -3.75 / 2.0;
							(*this).predicted[t].Y = -18 - (*this).V*(t-go_out_time+1)*Ts;
							(*this).predicted[t].sita = -PAI / 2;
						}
						else if ((*this).LocalLane == B0101)
						{
							(*this).predicted[t].X = 3.75 + 3.75 / 2.0;
							(*this).predicted[t].Y = 18 + (*this).V*(t-go_out_time+1)*Ts;
							(*this).predicted[t].sita = PAI / 2;
						}
						else if ((*this).LocalLane == B1100)
						{
							(*this).predicted[t].X = 18 + (*this).V*(t-go_out_time+1)*Ts;
							(*this).predicted[t].Y = -3.75 / 2.0;
							(*this).predicted[t].sita = 0;
						}
						else if ((*this).LocalLane == B1101)
						{
							(*this).predicted[t].X = -18 - (*this).V*(t-go_out_time+1)*Ts;
							(*this).predicted[t].Y = 3.75 + 3.75 / 2.0;
							(*this).predicted[t].sita = PAI;
						}
						t++;
					}
					break;
				}
			}
		}
		else
		{
			for (int t = 0; t < TimeStep; t++)
			{
				if ((*this).LocalLane / 8 == 0)
				{
					(*this).predicted[t].X = (*this).X + v * (t+1);
					(*this).predicted[t].Y = (*this).Y;
					(*this).predicted[t].sita = (((*this).LocalLane >> 2) & 1)*PAI;
				}
				else
				{
					(*this).predicted[t].X = (*this).X;
					(*this).predicted[t].Y = (*this).Y + v*(t+1);
					(*this).predicted[t].sita = PAI / 2.0 * (1 - 2 * (((*this).LocalLane >> 2) & 1));
				}
			}
		}
	}
}

int Vel::argmax(double P[])
{
	double ma = P[0];
	int index = 0;
	for (int i = 1; i < 3; i++)
	{
		if (P[i] > ma)
		{
			ma = P[i];
			index = i;
		}
	}
	return index+1;
}

void Vel::normaliz(double P[])
{
	double s = P[0]+ P[1] + P[2];
	this->P[0] /= s;
	this->P[1] /= s;
	this->P[2] /= s;
}
