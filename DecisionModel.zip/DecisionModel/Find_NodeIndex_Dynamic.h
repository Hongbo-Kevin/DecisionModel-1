#pragma once
#include <vector>
#include "Find_Min_Dynamic.h"
#ifndef __FIND_NODEINDEX_DYNAMIC_H__
#define __FIND_NODEINDEX_DYNAMIC_H__
int Find_NodeIndex_Dynamic(std::vector<SetInfo_t> &OpenSet, int x, int y, double r, int v, int t);
#endif