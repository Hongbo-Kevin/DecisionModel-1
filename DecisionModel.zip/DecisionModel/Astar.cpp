#include "stdafx.h"
#include "Astar.h"
#include "Find_NodeIndex_Dynamic.h"
#include "Cal_Dist.h"
#include "Expand_Nodes_Dynamic.h"
#include <assert.h>
#include "Declare_Vari.h"

double extension_squ_lenth=5,extension_squ_width=2,extension_circle_radius=0.5;
double map_precision=0.2;
int esl_half=ceil(extension_squ_lenth/map_precision/2),
	esw_half=ceil(extension_squ_width/map_precision/2),
	ecr=ceil(extension_circle_radius/map_precision);

int deal_with_target_area(int sequence_flag,Target &target,int TargetX,int TargetY,int FLAG)//FLAG 01�ֱ��ʾ�ָ�����չ
{
	if(sequence_flag==1)
	{
		if(target.Y>=-7.5&&target.Y<0)
		{
			int x1=TargetX - esl_half;
			int x2=TargetX + esl_half;
			int y1=TargetY - esw_half;
			int y2=TargetY + esw_half;
			x1=(x1<0?0:(x1>map.GridLength-1?map.GridLength-1:x1));
			x2=(x2<0?0:(x2>map.GridLength-1?map.GridLength-1:x2));
			y1=(y1<0?0:(y1>map.GridWidth-1?map.GridWidth-1:y1));
			y2=(y2<0?0:(y2>map.GridWidth-1?map.GridWidth-1:y2));
			for (int x = x1; x <= x2;x++)
				for (int y = y1; y <= y2; y++)
				{
					if(FLAG==1)
					{
						if(Map3D[Task+TimeStep].surface[x][y]!=48)
							Map3D[Task+TimeStep].surface[x][y] = 50;//2��ʾĿ��
					}
					else
					{
						if(Map3D[Task+TimeStep].surface[x][y]==50)
							Map3D[Task+TimeStep].surface[x][y] = 49;//2��ʾĿ���
					}
				}
		}
		else if(target.Y>18||target.Y<-18)
		{
			int x1= TargetX - esw_half;
			int x2= TargetX + esw_half;
			int y1=TargetY - esl_half;
			int y2=TargetY + esl_half;
			x1=(x1<0?0:(x1>map.GridLength-1?map.GridLength-1:x1));
			x2=(x2<0?0:(x2>map.GridLength-1?map.GridLength-1:x2));
			y1=(y1<0?0:(y1>map.GridWidth-1?map.GridWidth-1:y1));
			y2=(y2<0?0:(y2>map.GridWidth-1?map.GridWidth-1:y2));
			for (int x = x1; x <= x2;x++)
				for (int y = y1; y <= y2; y++)
				{
					if(FLAG==1)
					{
						if(Map3D[Task+TimeStep].surface[x][y]!=48)
							Map3D[Task+TimeStep].surface[x][y] =50;//2��ʾĿ���
					}
					else
					{
						if(Map3D[Task+TimeStep].surface[x][y]==50)
							Map3D[Task+TimeStep].surface[x][y] =49;//2��ʾĿ���
					}
				}
		}
		else
		{
			int x1= TargetX - ecr;
			int x2= TargetX + ecr;
			int y1= TargetY - ecr;
			int y2= TargetY + ecr;
			x1=(x1<0?0:(x1>map.GridLength-1?map.GridLength-1:x1));
			x2=(x2<0?0:(x2>map.GridLength-1?map.GridLength-1:x2));
			y1=(y1<0?0:(y1>map.GridWidth-1?map.GridWidth-1:y1));
			y2=(y2<0?0:(y2>map.GridWidth-1?map.GridWidth-1:y2));
			for (int x = x1; x <= x2;x++)
				for (int y = y1; y <= y2; y++)
				{
					if(FLAG==1)
					{
						if(Cal_Dist(x,y,TargetX,TargetY)<=ecr && Map3D[Task+TimeStep].surface[x][y]!=48)
							Map3D[Task+TimeStep].surface[x][y] =50;//2��ʾĿ���
					}
					else
					{
						if(Cal_Dist(x,y,TargetX,TargetY)<=ecr && Map3D[Task+TimeStep].surface[x][y]==50)
							Map3D[Task+TimeStep].surface[x][y] =49;//2��ʾĿ���
					}
				}

		}
	}
	else if(ego.X >= -18 && ego.X <= 18 && ego.Y >= -18 && ego.Y <= 18)//�ڶ��ι滮ֻҪ�Գ���ʮ��·�ڣ�Ŀ�����Բ������
	{
		if(target.Y>=-3.75&&target.Y<0)
		{
			int x1= TargetX - esl_half;
			int x2= TargetX + esl_half;
			int y1= TargetY - esw_half;
			int y2= TargetY + esw_half;
			x1=(x1<0?0:(x1>map.GridLength-1?map.GridLength-1:x1));
			x2=(x2<0?0:(x2>map.GridLength-1?map.GridLength-1:x2));
			y1=(y1<0?0:(y1>map.GridWidth-1?map.GridWidth-1:y1));
			y2=(y2<0?0:(y2>map.GridWidth-1?map.GridWidth-1:y2));
			for (int x = x1; x <= x2;x++)
				for (int y = y1; y <= y2; y++)
				{
					if(FLAG==1)
					{
						if(Map3D[Task+TimeStep].surface[x][y]!=48)
							Map3D[Task+TimeStep].surface[x][y] = 50;//2��ʾĿ���
					}
					else
					{
						if(Map3D[Task+TimeStep].surface[x][y]==50)
							Map3D[Task+TimeStep].surface[x][y] = 49;//2��ʾĿ���
					}
				}

		}
		else
		{
			int x1= TargetX - ecr;
			int x2= TargetX + ecr;
			int y1= TargetY - ecr;
			int y2= TargetY + ecr;
			x1=(x1<0?0:(x1>map.GridLength-1?map.GridLength-1:x1));
			x2=(x2<0?0:(x2>map.GridLength-1?map.GridLength-1:x2));
			y1=(y1<0?0:(y1>map.GridWidth-1?map.GridWidth-1:y1));
			y2=(y2<0?0:(y2>map.GridWidth-1?map.GridWidth-1:y2));
			for (int x = x1; x <= x2;x++)
				for (int y = y1; y <= y2; y++)
				{
					if(FLAG==1)
					{
						if(Cal_Dist(x,y,TargetX,TargetY)<=ecr && Map3D[Task+TimeStep].surface[x][y]!=48)
							Map3D[Task+TimeStep].surface[x][y] =50;//2��ʾĿ���
					}
					else
					{
						if(Cal_Dist(x,y,TargetX,TargetY)<=ecr && Map3D[Task+TimeStep].surface[x][y]==50)
							Map3D[Task+TimeStep].surface[x][y] =49;//2��ʾĿ���
					}
				}			
		}
	}
	else//�ڶ��ι滮������ʮ��·�ڣ���һ���ڽ���ʮ��·��֮ǰ��ֱ����
	{
		int x1= TargetX - esl_half;
		int x2= TargetX + esl_half;
		int y1= TargetY - esw_half;
		int y2= TargetY + esw_half;
		x1=(x1<0?0:(x1>map.GridLength-1?map.GridLength-1:x1));
		x2=(x2<0?0:(x2>map.GridLength-1?map.GridLength-1:x2));
		y1=(y1<0?0:(y1>map.GridWidth-1?map.GridWidth-1:y1));
		y2=(y2<0?0:(y2>map.GridWidth-1?map.GridWidth-1:y2));
		for (int x = x1; x <= x2;x++)
			for (int y = y1; y <= y2; y++)
			{
				if(FLAG==1)
				{
					if(Map3D[Task+TimeStep].surface[x][y]!=48)
						Map3D[Task+TimeStep].surface[x][y] = 50;//2��ʾĿ���
				}
				else
				{
					if(Map3D[Task+TimeStep].surface[x][y]==50)
						Map3D[Task+TimeStep].surface[x][y] = 49;//2��ʾĿ���
				}
			}		

	}
	return 0;
}

int deal_with_moving_obstacle(int FLAG)//FLAG 0��ʾ�ָ� 12��ʾ��չʱ����a*�Ĵ���
{
	if(FLAG==0||FLAG==1)//��һ�ε��òŶ�1-TimeStep�������չ
	{
		for (int i = 0; i < velID.size(); i++)
		{
			int id = velID[i];
			double diag_length=sqrt(vel[id].lengthForMap*vel[id].lengthForMap+vel[id].widthForMap*vel[id].widthForMap);
			if (vel[id].flag)		//��area��Χ�ڵ��ܳ�
			{
				for (int t = 1; t <=TimeStep; t++)
				{
					if(!vel[id].is_intersection)
					{
						if (vel[id].LocalLane / 8 == 0)	//��������
						{
							Grid a1=map.geo2grid(vel[id].predicted[t-1].X - vel[id].lengthForMap / 2.0,vel[id].predicted[t-1].Y - vel[id].widthForMap / 2.0);
							Grid a2=map.geo2grid(vel[id].predicted[t-1].X + vel[id].lengthForMap / 2.0,vel[id].predicted[t-1].Y + vel[id].widthForMap / 2.0);
							int X1=a1.gridx;
							int Y1=a1.gridy;
							int X2=a2.gridx;
							int Y2=a2.gridy;
							X1=(X1<0?0:(X1>map.GridLength-1?map.GridLength-1:X1));
							X2=(X2<0?0:(X2>map.GridLength-1?map.GridLength-1:X2));
							Y1=(Y1<0?0:(Y1>map.GridWidth-1?map.GridWidth-1:Y1));
							Y2=(Y2<0?0:(Y2>map.GridWidth-1?map.GridWidth-1:Y2));
							for (int x = X1; x <= X2; x++)
								for (int y = Y1; y <= Y2; y++)
								{
									if(FLAG==1)
										Map3D[t].surface[x][y] = 48;
									else
										Map3D[t].surface[x][y] = 51;
								}
						}
						else if(vel[id].LocalLane / 8 == 1)//�ϱ�����
						{
							Grid a1=map.geo2grid(vel[id].predicted[t-1].X - vel[id].widthForMap / 2.0,vel[id].predicted[t-1].Y - vel[id].lengthForMap / 2.0);
							Grid a2=map.geo2grid(vel[id].predicted[t-1].X + vel[id].widthForMap / 2.0,vel[id].predicted[t-1].Y + vel[id].lengthForMap / 2.0);
							int X1=a1.gridx;
							int Y1=a1.gridy;
							int X2=a2.gridx;
							int Y2=a2.gridy;
							X1=(X1<0?0:(X1>map.GridLength-1?map.GridLength-1:X1));
							X2=(X2<0?0:(X2>map.GridLength-1?map.GridLength-1:X2));
							Y1=(Y1<0?0:(Y1>map.GridWidth-1?map.GridWidth-1:Y1));
							Y2=(Y2<0?0:(Y2>map.GridWidth-1?map.GridWidth-1:Y2));
							for (int x = X1; x <= X2; x++)
								for (int y = Y1; y <= Y2; y++)
								{
									if(FLAG==1)
										Map3D[t].surface[x][y] = 48;
									else
										Map3D[t].surface[x][y] = 51;
								}
						}
					}
					else //ʮ��·�� 
					{
						Grid a1=map.geo2grid(vel[id].predicted[t-1].X - diag_length / 2.0,vel[id].predicted[t-1].Y - diag_length / 2.0);
						Grid a2=map.geo2grid(vel[id].predicted[t-1].X + diag_length / 2.0,vel[id].predicted[t-1].Y + diag_length / 2.0);
						int X1=a1.gridx;//��Խ��߷���Ľǵ���������
						int Y1=a1.gridy;
						int X2=a2.gridx;
						int Y2=a2.gridy;
						X1=(X1<0?0:(X1>map.GridLength-1?map.GridLength-1:X1));
						X2=(X2<0?0:(X2>map.GridLength-1?map.GridLength-1:X2));
						Y1=(Y1<0?0:(Y1>map.GridWidth-1?map.GridWidth-1:Y1));
						Y2=(Y2<0?0:(Y2>map.GridWidth-1?map.GridWidth-1:Y2));
						for (int x = X1; x <= X2; x++)//���������е�ÿ����
							for (int y = Y1; y <= Y2; y++)
							{
								Geo geo=map.grid2geo(x,y);
								double x_geo=geo.geox,y_geo=geo.geoy;//������������Ӧ����ʵ��������
								double x_trans=x_geo-vel[id].predicted[t-1].X,y_trans=y_geo-vel[id].predicted[t-1].Y;//�Գ������ĵ���ƽ�Ʊ任
								double x_rota=cos(vel[id].predicted[t-1].sita)*x_trans+sin(vel[id].predicted[t-1].sita)*y_trans,//�Գ������ĵ�����ת�任����ʱ����תsita+pi/2����һ�Ƕȷ�Ӧ������ʵ���෴����
									y_rota=-sin(vel[id].predicted[t-1].sita)*x_trans+cos(vel[id].predicted[t-1].sita)*y_trans;
								if(x_rota>=-vel[id].lengthForMap / 2.0&&x_rota<=vel[id].lengthForMap / 2.0
									&&y_rota>=-vel[id].widthForMap / 2.0&&y_rota<=vel[id].widthForMap / 2.0)
								{
									if(FLAG==1)
										Map3D[t].surface[x][y] = 48;
									else
										Map3D[t].surface[x][y] = 51;
								}							
							}
					}
				}
			}
		}
	}
	else//����surface��ԭ��һ������Ҫ����ÿһ��ıռ� FLAG=2�����
	{
		for (int t = 1; t <=TimeStep; t++)
		{
			for(int it=0;it<Map3D[t].ClosedSet.size();it++)
				delete[] Map3D[t].ClosedSet[it];
			Map3D[t].ClosedSet.clear();
		}
	}
	if(FLAG==0)
	{
		for (int t = 1; t <=TimeStep; t++)
		{
			for(int it=0;it<Map3D[t].ClosedSet.size();it++)
				delete[] Map3D[t].ClosedSet[it];
			Map3D[t].ClosedSet.clear();
		}
	}
	return 0;
}

bool Astar_algorithm(Ego ego, Target &target, vector<int> &velID,int sequence_flag)
{
	int searchtime_limit=(sequence_flag==1?70:30);
	OpenSet.clear();
	//Initialize the Map2D with input values

	// StartPosition
	Grid Start=map.geo2grid(ego.X,ego.Y);
	int StartX = Start.gridx, StartY =Start.gridy,
		StartV = int(ego.V*100+0.5);//v��cm/s
	double StartR = ego.Heading;//!!


	// Deal with Target
	Grid Target=map.geo2grid(target.X, target.Y);
	int TargetX = Target.gridx;
	int TargetY = Target.gridy;
	int TargetDesiredV=int(target.DesiredV*10+0.5);

	// Expand target area ����Map3D 0�㣨���ģ���ͼ��Ŀ��������
	deal_with_target_area(sequence_flag,target,TargetX,TargetY,1);


	//Deal with Moving Obstacle
	deal_with_moving_obstacle(sequence_flag);

	// Sets Used for Algorithm
	clock_t search_start,search_end;
	search_start=clock();
	int NodeNow_X = StartX, NodeNow_Y = StartY, NodeNow_V = StartV, NodeNow_T = 0;//NodeNow_TӦ��ָ���ǽڵ����ڵĵ�ͼ���� ��1��timestep����ʼ�ڵ�Ĳ���Ϊ��1
	double NodeNow_R = StartR, UpToNowCost = 0;
	double HeuristicCost = Cal_Dist(NodeNow_X, NodeNow_Y, TargetX, TargetY)/5;
	double TotalCost = HeuristicCost + UpToNowCost;
	SetInfo_t openset;
	int OpenSet_Count = 1;
	openset.set(0, NodeNow_X, NodeNow_Y, NodeNow_R, NodeNow_V, NodeNow_T,
		NodeNow_X, NodeNow_Y, NodeNow_R, NodeNow_V, NodeNow_T,
		UpToNowCost, HeuristicCost, TotalCost);
	OpenSet.push_back(openset);//����ʼ�ڵ����ȴ��뿪��
	int NoPath = 0;

	//Star A* algorithm
	while (Map3D[Task+TimeStep].surface[NodeNow_X][NodeNow_Y] != 50 && NoPath == 0&&NodeNow_T<TimeStep)
	{
		vector<ExpNodes_t> ExNodes;

		ExNodes = Expand_Nodes_Dynamic(NodeNow_X, NodeNow_Y, NodeNow_R, NodeNow_V, NodeNow_T, UpToNowCost,
			TargetX, TargetY, TargetDesiredV,target.CenterLine,map.GridLength-1, map.GridWidth-1, 100*SpeedLimit,
			Map3D[NodeNow_T + 1].surface, Map3D[NodeNow_T + 1].ClosedSet, Ts, Map3D[Task+TimeStep].surface,w,target.overtaking_flag);

		for (int i = 0; i < ExNodes.size(); i++)//����չ�Ľڵ���뿪��
		{
			SetInfo_t temp_openset;
			OpenSet_Count = OpenSet_Count + 1;
			temp_openset.set(1, ExNodes[i].x, ExNodes[i].y, ExNodes[i].r, ExNodes[i].v, NodeNow_T + 1,
				NodeNow_X, NodeNow_Y, NodeNow_R, NodeNow_V, NodeNow_T,
				ExNodes[i].Gn, ExNodes[i].Hn, ExNodes[i].Fn);
			OpenSet.push_back(temp_openset);
		}
		int MinNode = Find_Min_Dynamic(OpenSet, OpenSet_Count);

		if (MinNode != -1)
		{
			OpenSet[MinNode].Flag = 0;//�ڿ����н���ǰ�ڵ���Ϊ����ѡ
			NodeNow_T=OpenSet[MinNode].NodeNow_T;
			NodeNow_X=OpenSet[MinNode].NodeNow_X;
			NodeNow_Y=OpenSet[MinNode].NodeNow_Y;
			NodeNow_V=OpenSet[MinNode].NodeNow_V;
			NodeNow_R=OpenSet[MinNode].NodeNow_R;
		}
		else 
			NoPath = 1;
		search_end=clock();
		if(search_end-search_start>searchtime_limit)
		{
			//�㷨����ǰ�ָ�Ŀ������Ϊ��ʼ��ʱ�����
			deal_with_target_area(sequence_flag,target,TargetX,TargetY,0);
			return false;
		}
	}


	//Find Optimal Path
	OptimalPath.clear();
	Path optimalpath;
	if (Map3D[Task+TimeStep].surface[NodeNow_X][NodeNow_Y] == 50)
	{
		if(NodeNow_X!=StartX||NodeNow_Y!=StartY)
		{
			optimalpath.set(NodeNow_X, NodeNow_Y, NodeNow_R, NodeNow_V, NodeNow_T);
			OptimalPath.push_back(optimalpath);//ע�⣡OptimalPath�еĵ㶼��դ���ͼ�еģ������ǵ������꣡
			int node = Find_NodeIndex_Dynamic(OpenSet, NodeNow_X, NodeNow_Y, NodeNow_R, NodeNow_V, NodeNow_T);//�ҿ����нڵ�ţ������Ҹ��ڵ�
			int parent_x = OpenSet[node].NodeNow1_X;
			int parent_y = OpenSet[node].NodeNow1_Y;
			double parent_r = OpenSet[node].NodeNow1_R;
			int parent_v = OpenSet[node].NodeNow1_V;
			int parent_t = OpenSet[node].NodeNow1_T;


			while (parent_t != 0)
			{
				optimalpath.set(parent_x, parent_y, parent_r, parent_v, parent_t);
				OptimalPath.push_back(optimalpath);
				node = Find_NodeIndex_Dynamic(OpenSet, parent_x, parent_y, parent_r, parent_v, parent_t);
				parent_x = OpenSet[node].NodeNow1_X;
				parent_y = OpenSet[node].NodeNow1_Y;
				parent_r = OpenSet[node].NodeNow1_R;
				parent_v = OpenSet[node].NodeNow1_V;
				parent_t = OpenSet[node].NodeNow1_T;
			}
		}
		else
		{
			int next_x,next_y,next_v,next_t=1;
			double next_r=(ego.is_intersection?NodeNow_R:0);
			next_v=(NodeNow_V-Ts*400>0?NodeNow_V-Ts*400:0);
			next_x=(int)(NodeNow_X+Ts*next_v/10.0*cos(next_r)/2+0.5);
			next_y=(int)(NodeNow_Y+Ts*next_v/10.0*sin(next_r)/2+0.5);
			optimalpath.set(next_x, next_y, next_r, next_v, next_t);
			OptimalPath.push_back(optimalpath);
		}
		//�㷨����ǰ��target�仯ǰ�ָ�Ŀ������Ϊ��ʼ��ʱ�����
		deal_with_target_area(sequence_flag,target,TargetX,TargetY,0);
		return true;
	}
	else
	{
		//�㷨����ǰ�ָ�Ŀ������Ϊ��ʼ��ʱ�����
		deal_with_target_area(sequence_flag,target,TargetX,TargetY,0);
		return false;
	}
}