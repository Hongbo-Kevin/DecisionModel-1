#include "stdafx.h"
#include "EGO.h"
#include "MAP.h"
#include "Declare_Vari.h"


#define B0000 0
#define B0001 1
#define B0010 2
#define B0011 3
#define B0100 4
#define B0101 5
#define B0110 6
#define B0111 7
#define B1000 8
#define B1001 9
#define B1010 10
#define B1011 11
#define B1100 12
#define B1101 13
#define B1110 14
#define B1111 15

float Ego::length=4.8;//��ֵVel���еľ�̬��Ա
float Ego::width=1.8;
float Ego::center2head=3.3;
float Ego::center2tail=1.5;
static bool TurnLeft_is_care;//��ʮ��·����תʱ�Ƿ���Ҫ���Ķ�������

void ResetTargetX(Target &target,Ego ego)//�������ٶȶ�һ���ܵ����x
{
	if(target.DesiredV>ego.V)
	{
		if(ego.V>=2)
			target.X=min(target.X,ego.X+ego.V*predirt_time);
		else
			target.X=min(target.X,ego.X+10);
	}
	else
		target.X=min(target.X,ego.X+target.DesiredV*predirt_time);
}
void ResetTargetPositionInCross(Target &target,Ego ego,double delta)
{
	if(Task==2)
	{
		double d1,d2;
		double tempx,tempy;
		if(ego.X<-TurnLeftR)
			d1=ego.X+18;
		else if(ego.Y>TurnLeftR)
			d1=2.0*(18-TurnLeftR)+0.5*PAI*(TurnLeftR+1.875)-(18-ego.Y);
		else
			d1=18-TurnLeftR+asin((ego.X+TurnLeftR)/(TurnLeftR+1.875))*(TurnLeftR+1.875);
		d2=d1+delta;
		if(d2<18-TurnLeftR)
		{
			tempx=d2-18;
			tempy=-3.75/2;
		}
		else if(d2>18-TurnLeftR+PAI*(TurnLeftR+1.875)/2.0)
		{
			tempx=3.75/2;
			tempy=TurnLeftR+d2-(18-TurnLeftR+PAI*(TurnLeftR+1.875)/2.0);
		}
		else
		{
			tempx=-TurnLeftR+(TurnLeftR+1.875)*sin((d2-(18-TurnLeftR))/(TurnLeftR+1.875));
			tempy=TurnLeftR-(TurnLeftR+1.875)*cos((d2-(18-TurnLeftR))/(TurnLeftR+1.875));
		}
		if(tempy<target.Y)
		{
			target.X=tempx;
			target.Y=tempy;
		}
	}
	else if(Task==3)
	{
		double r=12.375;
		double d1,d2,tempx,tempy;
		d1=r*asin((ego.X+18)/r);
		d2=d1+delta;
		if(d2>0.5*PAI*r)
		{
			tempx=-5.625;
			tempy=-18-(d2-0.5*PAI*r);
		}
		else
		{
			tempx=-18+r*sin(d2/r);
			tempy=-18+r*cos(d2/r);
		}
		if(tempy>target.Y)
		{
			target.X=tempx;
			target.Y=tempy;
		}
	}
	else
		assert(0);
}
bool exist_neigback_veh(int back_dis)
{
	bool flag=false;
	for(int i=0;i<velID.size();i++)//����������ں�
	{
		if (vel[velID[i]].flag)
		{
			if(vel[velID[i]].LocalLane!=ego.LocalLane&&ego.X-vel[velID[i]].X>0&&ego.X-vel[velID[i]].X<back_dis)
			{
				flag==true;
				break;
			}
		}
	}
	return flag;
}

Ego::Ego(){}
Target Ego::DrivingGoal(int Task, int TrafficLight)
{
	Target target;
	if (Task == 2)   //��ת
	{
		target.now_line =B0000;
		target.next_line = B1010;
	}
	else if (Task == 3)  //��ת
	{
		target.now_line =B0001;
		target.next_line = B1111;
	}
	else if (Task == 1)    //ֱ��
	{
		target.now_line = B0000; //����Ŀ�공��=�Է�Ŀ�공��=ֱ���Գ����ڳ���
		target.next_line=B0010;
	}

	double dis = fabs((*this).X);

	if(dis>584)
	{
		target.Y = map.line[this->LocalLane].centerLine;
		if(frontvel[0]==-1)
		{
			target.X = (*this).X +25*(1+ego.V/SpeedLimit);
			target.DesiredV =16;
		}
		else
		{
			target.X = vel[frontvel[0]].X-vel[frontvel[0]].lengthForMap/2;
			target.DesiredV = (vel[frontvel[0]].X-ego.X)/2.0;
		}
		target.CenterLine = map.line[this->LocalLane].centerLine; //Ŀ�공�������߾������ڳ���������
	}
	else if (dis > 100 + 18)      //�Գ��౾��ֹͣ�߾���>100m
	{
		if(ego.LocalLane!=target.now_line)
		{
			if(frontvel[1]==-1)//���ڳ���û��ǰ��
			{
				target.X = (*this).X +25*(1+0.5*ego.V/SpeedLimit);
				target.Y = map.line[target.now_line].centerLine;
				target.DesiredV =16;
				target.CenterLine = map.line[target.now_line].centerLine; //Ŀ�공�������߾���Ŀ�공��������
				target.overtaking_flag=exist_neigback_veh(20);
			}
			else
			{
				if(vel[frontvel[1]].V>16)//���ڳ������ٸߣ�������������
				{
					target.X = (*this).X +25*(1+0.5*ego.V/SpeedLimit);
					target.Y = map.line[target.now_line].centerLine;
					target.DesiredV =16;
					target.CenterLine = map.line[target.now_line].centerLine; //Ŀ�공�������߾���Ŀ�공��������
					target.overtaking_flag=exist_neigback_veh(20);
				}
				else//���ڳ������ٵ� ����
				{
					if(frontvel[0]!=-1&&fabs(vel[frontvel[0]].X-vel[frontvel[1]].X)<30)
					{
						target.X = vel[frontvel[0]].X-vel[frontvel[0]].lengthForMap/2;
						target.Y = map.line[ego.LocalLane].centerLine;
						target.CenterLine = map.line[ego.LocalLane].centerLine; //Ŀ�������߾���Ŀ�공��������
						target.DesiredV = (vel[frontvel[0]].X-ego.X)/2.0;
					}
					else
					{
						target.X = (*this).X +25;
						target.Y = map.line[ego.LocalLane].centerLine;
						target.DesiredV =16;
						target.CenterLine = map.line[ego.LocalLane].centerLine; //Ŀ�공�������߾���Ŀ�공��������
						target.overtaking_flag==true;
					}
				}
			}
		}
		else
		{
			if(frontvel[0]==-1)//��ǰ��
			{
				target.X = (*this).X +25*(1+0.5*ego.V/SpeedLimit);
				target.Y = map.line[target.now_line].centerLine;
				target.DesiredV =16;
				target.CenterLine = map.line[target.now_line].centerLine; //Ŀ�공�������߾������ڳ���������
			}
			else
			{
				if(dis<200||vel[frontvel[0]].X-ego.X>20||vel[frontvel[0]].V>16||
					(frontvel[1]!=-1&&fabs(vel[frontvel[0]].X-vel[frontvel[1]].X)<30)||exist_neigback_veh(15))
				{
					target.X = vel[frontvel[0]].X-vel[frontvel[0]].lengthForMap/2;
					target.Y = map.line[target.now_line].centerLine;
					target.CenterLine = map.line[target.now_line].centerLine; //Ŀ�������߾���Ŀ�공��������
					target.DesiredV = (vel[frontvel[0]].X-ego.X)/2.0;
				}
				else
				{
					target.X =vel[frontvel[0]].X+10;
					target.Y = map.line[(target.now_line==B0000?B0001:B0000)].centerLine;
					target.CenterLine = map.line[(target.now_line==B0000?B0001:B0000)].centerLine; //Ŀ�공�������߾������ڳ���������
					target.DesiredV =16;
					target.overtaking_flag==true;
				}
			}
		}
	}
	else if (dis >= 20 + 18)//20m�ܾ��룼100m
	{
		if(ego.LocalLane!=target.now_line&&ego.V>3)//���ڳ��Գ�������ʱ���ٻ���
		{
			if(fabs(ego.Y+3.75)<1)
			{
				target.X =(frontvel[1]==-1?(*this).X +25:vel[frontvel[1]].X-5);
				target.Y = map.line[target.now_line].centerLine;
				target.DesiredV =16;
				target.CenterLine = map.line[target.now_line].centerLine; //Ŀ�공�������߾���Ŀ�공��������
				target.overtaking_flag=exist_neigback_veh(20);
			}
			else
			{
				target.X = (*this).X +20;
				target.Y = map.line[ego.LocalLane].centerLine;
				target.DesiredV =2.5;
				target.CenterLine = map.line[ego.LocalLane].centerLine;
			}	
		}
		else
		{
			target.X = (*this).X +20, target.Y = map.line[target.now_line].centerLine;
			target.DesiredV = 7;
			target.CenterLine = map.line[target.now_line].centerLine; //Ŀ�공�������߾��� ����Ŀ�공��
		}
	}
	else if (dis > 18) //0<���룼20m
	{
		TurnLeft_is_care=true;
		if (TrafficLight == 0&&Task!=3)   //���
		{
			target.X = map.line[target.now_line].stopLine-3, target.Y = map.line[target.now_line].centerLine;
			target.DesiredV = 3;
			target.CenterLine = map.line[target.now_line].centerLine; //Ŀ�공�������߾��� ����Ŀ�공��
			ResetTargetX(target,ego);
		}
		else    //�̵�
		{
			if((*this).X +20>-13)
				target.X = map.line[target.now_line].stopLine + 5;
			else
				target.X = (*this).X +20;
			target.Y = map.line[target.now_line].centerLine;
			if(this->X>-28)//��ʮ��·��ʱ���ٶȵ���
			{
				if(frontvel[0]!=-1)//��ǰ����һ��Ҫ�����ٶ�
				{
					target.DesiredV = 3;
					ResetTargetX(target,ego);
				}

				else//��ǰ��
				{
					if(Task==2)//��תʱ��Ҫ��ǰ����
					{
						bool flag=false;
						for(int i=0;i<velID.size();i++)
						{
							if (vel[velID[i]].flag)
							{
								if((vel[velID[i]].LocalLane==B0100&&vel[velID[i]].Y>1&&vel[velID[i]].X<30)||
									(vel[velID[i]].LocalLane==B0101&&vel[velID[i]].Y<4.75))
								{
									flag=true;
									break;
								}
							}
						}
						if(flag==true)
						{
							target.DesiredV = 3;
							ResetTargetX(target,ego);
						}
						else
							target.DesiredV = 7;
					}
					else if(Task==1)//ֱ��
					{
						bool flag=false;
						for(int i=0;i<velID.size();i++)
						{
							if (vel[velID[i]].flag)
							{
								if(vel[velID[i]].LocalLane==B0100&&vel[velID[i]].Y<1)
								{
									flag=true;
									break;
								}
							}
						}
						if(flag==true)
						{
							target.DesiredV = 6;
							ResetTargetX(target,ego);
						}
						else
							target.DesiredV = 7;
					}
					else//��ת�������
						target.DesiredV = 7;
				}
			}
			else
				target.DesiredV = 7;
			target.CenterLine = map.line[target.now_line].centerLine; //Ŀ�공�������߾��� ����Ŀ�공��
		}
	}
	else//�Գ���ʮ��·��������
	{
		if (Task == 2)   //��ת
		{
			if(TurnLeft_is_care)
			{
				bool flag=false;//ȡ�����ܳ����Ƿ���Ķ�����������ʼ��Ϊ������
				for(int i=0;i<velID.size();i++)
				{
					if (vel[velID[i]].flag)
					{
						if(((vel[velID[i]].LocalLane==B0100&&vel[velID[i]].Y>1)||(vel[velID[i]].LocalLane==B0101&&vel[velID[i]].Y<4.75))
							&&vel[velID[i]].X>this->X+3&&((vel[velID[i]].X)/(vel[velID[i]].V+1)<4||vel[velID[i]].X<18))//vel[velID[i]].X<(TrafficLight==1?30:18)&&(this->X<-TurnLeftR-2||vel[velID[i]].V>1)
						{
							flag=true;
							break;
						}
					}
				}
				if(this->Y>0||this->V>4.5||(!flag&&this->X>-TurnLeftR-2.5))//TurnLeft_is_care��һʱ����false��ʮ��·���Ժ�ȫ��false
					TurnLeft_is_care=false;
			}
			if(!TurnLeft_is_care)
			{
				for(int i=0;i<velID.size();i++)
				{
					if (vel[velID[i]].flag)
					{
						if((vel[velID[i]].LocalLane==B0100||(vel[velID[i]].LocalLane==B0101&&vel[velID[i]].Y<4.75)))//&&vel[velID[i]].V>2
							vel[velID[i]].flag=0;
					}
				}
			}
			if(this->X<-TurnLeftR-2.5||TurnLeft_is_care)//(*this).Y<10-4||TrafficLight==0
			{
				target.X = -TurnLeftR;//1.875;
				target.Y = -1.875;//10;
				target.DesiredV = 3;
				for(int i=0;i<velID.size();i++)
				{
					if (vel[velID[i]].flag)
					{
						if(vel[velID[i]].X>this->X&&vel[velID[i]].X<0&&vel[velID[i]].Y>-3.75&&vel[velID[i]].Y<-2)
						{
							target.X = ego.X;//1.875;
							target.Y = ego.Y;
							break;
						}
					}
				}
			}
			else
			{
				target.X = map.line[target.next_line].centerLine;
				target.Y = map.line[target.next_line].stopLine + 5;
				if(this->Y<5)
					ResetTargetPositionInCross(target,ego,12);
				if(frontvel[0]!=-1&&vel[frontvel[0]].Y<18+5)
					target.DesiredV=4;
				else
					target.DesiredV=7;
			}	
		}
		else if (Task == 3)  //��ת
		{
			target.X = map.line[target.next_line].centerLine;
			target.Y = map.line[target.next_line].stopLine - 5;
			if(frontvel[0]!=-1&&vel[frontvel[0]].Y>-18-10)
			{
				ResetTargetPositionInCross(target,ego,10);
				target.DesiredV=3.5;
			}
			else
				target.DesiredV=7;

		}
		else if (Task == 1)    //ֱ��
		{
			target.X = map.line[target.next_line].stopLine+5;	
			target.DesiredV = 7;
			target.Y = map.line[target.next_line].centerLine;
			target.CenterLine=map.line[target.next_line].centerLine;
			for(int i=0;i<velID.size();i++)
			{
				if (vel[velID[i]].flag)
				{
					if(vel[velID[i]].LocalLane==B0100&&vel[velID[i]].Y<1.5&&vel[velID[i]].V<1
						&&vel[velID[i]].X>this->X&&vel[velID[i]].X<this->X+10)
					{
						vel[velID[i]].lengthForMap=(vel[velID[i]].length/2+1)*2;
						vel[velID[i]].widthForMap=(vel[velID[i]].width/2+0.5)*2;
					}
				}
			}
			for(int i=0;i<velID.size();i++)
			{
				if (vel[velID[i]].flag)
				{
					if(vel[velID[i]].LocalLane==B0100&&vel[velID[i]].Y<1.7&&vel[velID[i]].Y>-4&&vel[velID[i]].X>this->X+3&&vel[velID[i]].X<18)//(12-this->X)/(this->V+1)>3
					{
						if(vel[velID[i]].V>1)
						{
							target.DesiredV =0;
							break;
						}
						else
							target.DesiredV=2;
					}
				}
			}
			ResetTargetX(target,ego);
		}
	}
	return target;
}

bool Ego::is_front(Vel &veh)
{
	if(X<-18||Task==1)
		if(veh.X>=X)
			return true;
		else
			return false;
	else if(X>=-18&&Task==2)
	{
		if(veh.Y>=tan(-PAI/2+Heading)*(veh.X-X)+Y)
			return true;
		else
			return false;
	}
	else if(X>=-18&&Task==3)
	{
		if(veh.Y<=tan(PAI/2+Heading)*(veh.X-X)+Y)
			return true;
		else
			return false;
	}
	else
		assert(0);
}
Ego::~Ego(){}
