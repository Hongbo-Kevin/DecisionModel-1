#pragma once
#include <vector>
typedef struct SetInfo_T {
	int Flag, NodeNow_X, NodeNow_Y, NodeNow_V, NodeNow_T,
		NodeNow1_X, NodeNow1_Y, NodeNow1_V, NodeNow1_T;
	double  NodeNow_R, NodeNow1_R;
	double UpToNowCost, HeuristicCost, TotalCost;
	void set(int flag, int _NodeNow_X, int _NodeNow_Y, double _NodeNow_R, int _NodeNow_V, int _NodeNow_T,
		int _NodeNow1_X, int _NodeNow1_Y, double _NodeNow1_R, int _NodeNow1_V, int _NodeNow1_T,
		double _UpToNowCost, double _HeuristicCost, double _TotalCost)
	{
		Flag = flag;
		NodeNow_X = _NodeNow_X;
		NodeNow_Y = _NodeNow_Y;
		NodeNow_R = _NodeNow_R;
		NodeNow_V = _NodeNow_V;
		NodeNow_T = _NodeNow_T;
		NodeNow1_X = _NodeNow1_X;
		NodeNow1_Y = _NodeNow1_Y;
		NodeNow1_R = _NodeNow1_R;
		NodeNow1_V = _NodeNow1_V;
		NodeNow1_T = _NodeNow1_T;
		UpToNowCost = _UpToNowCost;
		HeuristicCost = _HeuristicCost;
		TotalCost = _TotalCost;
	}
}SetInfo_t;
//extern SetInfo_t;
typedef struct temp_array_T {
	int a1, a2, a3, a5, a6, a7, a8, a9, a10, a11, a12;
	double a4;
	double a13, a14, a15;
	void set(int _a1, int _a2, int _a3, double _a4, int _a5,
		int _a6, int _a7, int _a8, int _a9, int _a10,
		int _a11, int _a12, double _a13, double _a14, double _a15)
	{
		a1 = _a1;
		a2 = _a2;
		a3 = _a3;
		a4 = _a4;
		a5 = _a5;
		a6 = _a6;
		a6 = _a7;
		a8 = _a8;
		a9 = _a9;
		a10 = _a10;
		a11 = _a11;
		a12 = _a12;
		a13 = _a13;
		a14 = (int)(_a14*1000000)/1000000.0;
		a15 = _a15;
	}
}temp_array_t;
class heap
{
private:
	std::vector<temp_array_t> data;
	void swap(int i, int j)
	{
		temp_array_t temp = data[i];
		data[i] = data[j];
		data[j] = temp;
	}
public:
	heap()
	{
		temp_array_t nulltrail;
		data.push_back(nulltrail);
	}
	void push(temp_array_t datum)
	{
		int i = data.size();
		data.push_back(datum);
		while (i > 1)
		{
			if ((data[i >> 1].a14 > data[i].a14)||
				((data[i >> 1].a14 == data[i].a14)&&(fabs(data[i >> 1].a4)>=fabs(data[i].a4))))//��totalcostһ��ʱ��ȡ�ǶȾ���ֵ��С���Ǹ�,ȡ�Ⱥ�
				swap(i, i >> 1);                                                               //����Ϊ���Ƕ�Ҳһ����ôȡ����ٶ� 
			i >>= 1;
		}
	}
	temp_array_t find_min()
	{
		return data[1];
	}
	~heap(){}
};
#ifndef __FIND_MIN_DYNAMIC_H__
#define __FIND_MIN_DYNAMIC_H__
int Find_Min_Dynamic(std::vector<SetInfo_t> &OpenSet, int OpSetCount);
#endif
