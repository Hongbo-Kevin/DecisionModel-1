#include "stdafx.h"
//���룺�ڵ��ʱ��t��x���꣬y���꣬��ǰ�ٶ�v
//�����APF�������ú��ֵ

#include "APF.h"
#include "VEL.h"
#include "MAP.h"
#include "Declare_Vari.h"

double a=1,b=1,c=1,d=0.1,e=2,f=2,lowestV=2;
bool is_same_lane(double y1,double y2)
{
	assert(y1!=-3.75&&y2!=-3.75);
	if((y1>-3.75&&y2>-3.75)||(y1<-3.75&&y2<-3.75))
		return true;
	else
		return false;
}
bool in_interested_area(double y)
{
	if(y<0&&y>-7.5)
		return true;
	else
		return false;
}
double APF(int node_t, int x, int y, int v)
{
	int id0=frontvel[0],id1=frontvel[1];
	double potential,delta_d,delta_v;
	Geo Node_geo=map.grid2geo(x,y);
	double node_geox=Node_geo.geox,node_geoy=Node_geo.geoy;
	if(id0!=-1&&id1==-1)//��������ǰ��,����������ǰ��
	{
		Grid Vel_grid=map.geo2grid(vel[id0].predicted[node_t-1].X-vel[id0].lengthForMap/2,vel[id0].predicted[node_t-1].Y);//
		int vel_gridx=Vel_grid.gridx,vel_gridy=Vel_grid.gridy;
		if(vel_gridx<=x||!is_same_lane(node_geoy,vel[id0].predicted[node_t-1].Y)
			||!in_interested_area(vel[id0].predicted[node_t-1].Y)||vel[id0].V<lowestV)
			return 0;
		else
			delta_d=(vel_gridx-x)*0.2;//��λm
		delta_v=v/100.0-vel[id0].V;//��λm/s
		if((int)(fabs(c*delta_v + d)*10000)/10000.0>0.0001&&(int)(b*delta_d / (c*delta_v + d)*10000)/10000.0!=2)
			potential = a / pow(b*delta_d / (c*delta_v + d) - e,f);
		else 
			potential=0;
		return potential;
	}
	else if(id0!=-1&&id1!=-1)//�����������ڳ�������ǰ��
	{
		Grid Vel_grid=map.geo2grid(vel[id0].predicted[node_t-1].X-vel[id0].lengthForMap/2,vel[id0].predicted[node_t-1].Y);//
		int vel_gridx=Vel_grid.gridx,vel_gridy=Vel_grid.gridy;
		Grid neiVel_grid=map.geo2grid(vel[id1].predicted[node_t-1].X-vel[id1].lengthForMap/2,vel[id1].predicted[node_t-1].Y);//
		int neivel_gridx=neiVel_grid.gridx,neivel_gridy=neiVel_grid.gridy;
		if(!in_interested_area(vel[id0].predicted[node_t-1].Y)&&
			!in_interested_area(vel[id1].predicted[node_t-1].Y))//Ԥ��㶼������Ȥ
			return 0;
		else if(in_interested_area(vel[id0].predicted[node_t-1].Y)&&
			!in_interested_area(vel[id1].predicted[node_t-1].Y))//������Ԥ������Ȥ
		{
			if(vel_gridx<=x||!is_same_lane(node_geoy,vel[id0].predicted[node_t-1].Y)||vel[id0].V<lowestV)
				return 0;
			else
				delta_d=(vel_gridx-x)*0.2;//��λm
			delta_v=v/100.0-vel[id0].V;//��λm/s
			if((int)(fabs(c*delta_v + d)*10000)/10000.0>0.0001&&(int)(b*delta_d / (c*delta_v + d)*10000)/10000.0!=2)
				potential = a / pow(b*delta_d / (c*delta_v + d) - e,f);
			else 
				potential=0;
			return potential;
		}
		else if(!in_interested_area(vel[id0].predicted[node_t-1].Y)&&
			in_interested_area(vel[id1].predicted[node_t-1].Y))//���ڳ���Ԥ������Ȥ
		{
			if(neivel_gridx<=x||!is_same_lane(node_geoy,vel[id1].predicted[node_t-1].Y)||vel[id1].V<lowestV)
				return 0;
			else
				delta_d=(neivel_gridx-x)*0.2;//��λm
			delta_v=v/100.0-vel[id1].V;//��λm/s
			if((int)(fabs(c*delta_v + d)*10000)/10000.0>0.0001&&(int)(b*delta_d / (c*delta_v + d)*10000)/10000.0!=2)
				potential = a / pow(b*delta_d / (c*delta_v + d) - e,f);
			else 
				potential=0;
			return potential;
		}
		else//������Ȥ����Ҫ��˭����ͬ������
		{
			if(is_same_lane(node_geoy,vel[id0].predicted[node_t-1].Y)&&
				!is_same_lane(node_geoy,vel[id1].predicted[node_t-1].Y))//������Ԥ���������ͬһ����
			{
ben:
				if(vel_gridx<=x||vel[id0].V<lowestV)
					return 0;
				else
					delta_d=(vel_gridx-x)*0.2;//��λm
				delta_v=v/100.0-vel[id0].V;//��λm/s
				if((int)(fabs(c*delta_v + d)*10000)/10000.0>0.0001&&(int)(b*delta_d / (c*delta_v + d)*10000)/10000.0!=2)
					potential = a / pow(b*delta_d / (c*delta_v + d) - e,f);
				else 
					potential=0;
				return potential;
			}
			else if(!is_same_lane(node_geoy,vel[id0].predicted[node_t-1].Y)&&
				is_same_lane(node_geoy,vel[id1].predicted[node_t-1].Y))//���ڳ���Ԥ���������ͬһ����
			{
lin:
				if(neivel_gridx<=x||vel[id1].V<lowestV)
					return 0;
				else
					delta_d=(neivel_gridx-x)*0.2;//��λm
				delta_v=v/100.0-vel[id1].V;//��λm/s
				if((int)(fabs(c*delta_v + d)*10000)/10000.0>0.0001&&(int)(b*delta_d / (c*delta_v + d)*10000)/10000.0!=2)
					potential = a / pow(b*delta_d / (c*delta_v + d) - e,f);
				else 
					potential=0;
				return potential;
			}
			else//����ͬһ��������Ҫ�Ƚ�x��
			{
				if(vel_gridx<=x&&neivel_gridx<=x)
					return 0;
				else if(vel_gridx<=x&&neivel_gridx>x)
					goto lin;
				else if(vel_gridx>x&&neivel_gridx<=x)
					goto ben;
				else
				{
					if(vel_gridx>neivel_gridx)
						goto lin;
					else
						goto ben;
				}
			}
		}
	}
	else if(id0==-1&&id1!=-1)//ֻ�����ڳ�����ǰ��
	{
		Grid neiVel_grid=map.geo2grid(vel[id1].predicted[node_t-1].X-vel[id1].lengthForMap/2,vel[id1].predicted[node_t-1].Y);//
		int neivel_gridx=neiVel_grid.gridx,neivel_gridy=neiVel_grid.gridy;
		if(neivel_gridx<=x||!is_same_lane(node_geoy,vel[id1].predicted[node_t-1].Y)
			||!in_interested_area(vel[id1].predicted[node_t-1].Y)||vel[id1].V<lowestV)
			return 0;
		else
			delta_d=(neivel_gridx-x)*0.2;//��λm
		delta_v=v/100.0-vel[id1].V;//��λm/s
		if((int)(fabs(c*delta_v + d)*10000)/10000.0>0.0001&&(int)(b*delta_d / (c*delta_v + d)*10000)/10000.0!=2)
			potential = a / pow(b*delta_d / (c*delta_v + d) - e,f);
		else 
			potential=0;
		return potential;
	}
	else//��û��ǰ��
		return 0;
}
