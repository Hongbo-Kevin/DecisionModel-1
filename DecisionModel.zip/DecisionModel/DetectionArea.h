#pragma once
#include <string>
#include "EGO.h"
bool SurroundingVehicleDetection(Vel &m_vel, std::string area);
void markInArea(std::string area, std::vector<int> &velID);
void DetectionArea(std::vector<int> &velID);
