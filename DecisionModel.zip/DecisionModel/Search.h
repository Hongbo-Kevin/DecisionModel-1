#pragma once
#include "EGO.h"
#ifndef __SEARCH_H__
#define __SEARCH_H__
void Search(Ego ego, int &Task, std::vector<int> &velID);
#endif